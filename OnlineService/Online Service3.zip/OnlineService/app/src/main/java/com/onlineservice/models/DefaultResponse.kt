package com.onlineservice.models

data class DefaultResponse(
    val message: String,
    val error: Boolean
)

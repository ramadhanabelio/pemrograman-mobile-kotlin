package com.onlineservice.services

import com.onlineservice.models.DefaultResponse
import com.onlineservice.models.LoginResponse
import com.onlineservice.models.User
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.QueryMap

interface UserService {
    @POST("users")
    fun registerUser(
        @Body newUser: User
    ) : Call<DefaultResponse>

    @GET("login")
    fun loginUser(
        @QueryMap filter: HashMap<String, String>
    ) : Call<LoginResponse>
}